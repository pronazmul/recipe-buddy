<h1 align="center"> Recipe Buddy Nodejs Monolithic Application</h1>
